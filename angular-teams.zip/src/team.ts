export class Team {
    id: number;
    name: string;
    administrator: string;
    description: string;  
}