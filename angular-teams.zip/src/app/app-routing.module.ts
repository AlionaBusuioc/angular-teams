import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyTeamsComponent } from './my-teams/my-teams.component';
import { CrTeamComponent } from './cr-team/cr-team.component';
import { SettingsComponent } from './settings/settings.component';
import { UsersComponent } from './settings/users/users.component';

const routes: Routes = [
  { path: '', redirectTo: '/cr-team', pathMatch: 'full' },
  { path: 'cr-team', component: CrTeamComponent },
  { path: 'team', component: MyTeamsComponent },
  { path: 'settings', component: SettingsComponent},
  { path: 'users', component: UsersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
