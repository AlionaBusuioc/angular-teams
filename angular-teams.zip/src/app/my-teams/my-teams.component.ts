import { Component, OnInit } from '@angular/core';

import { Team } from '../../team';
import { TeamService } from '../../team.service';

@Component({
  selector: 'app-my-teams',
  templateUrl: './my-teams.component.html',
  styleUrls: ['./my-teams.component.css']
})
export class MyTeamsComponent implements OnInit {
  teams: Team[];

  constructor(private teamService: TeamService) { }

  ngOnInit() {
    this.getTeams();
  }

  getTeams(): void {
    this.teamService.getTeams()
    .subscribe(teams => this.teams = teams);
  }

  delete(team: Team): void {
    this.teams = this.teams.filter(h => h !== team);
    this.teamService.deleteTeam(team).subscribe();
  }
}