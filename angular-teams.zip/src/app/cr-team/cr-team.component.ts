import { Component, OnInit } from '@angular/core';

import { Team } from '../../team';
import { TeamService } from '../../team.service';
import { TEMPORARY_NAME } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'app-cr-team',
  templateUrl: './cr-team.component.html',
  styleUrls: ['./cr-team.component.css']
})
export class CrTeamComponent implements OnInit {
  teams: Team[];
  tName: string;
  constructor(private teamService: TeamService) { }

  ngOnInit() {
    this.getTeams();
  }
  getTeams(): void {
    this.teamService.getTeams()
    .subscribe(teams => this.teams = teams);
  }
  // submitted = false;
  // onSubmit() { this.submitted = true; }

  add(name: string, description: string): void {
    name = name.trim();
    if (!name && description) { return; }
    this.teamService.addTeam({ name, description } as Team)
      .subscribe(team => {
        this.teams.push(team);
      });
  }

}
