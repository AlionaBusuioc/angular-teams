import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Team } from './team';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
  })
  export class InMemoryDataService implements InMemoryDbService {
    createDb() {
      const teams = [
      {id: 1, name: "FrontEnd", description : "SSD Front End developers"},
      {id: 2, name: "BackEnd", description : " SSD Back End developers"}
      ];
      return {teams};
    }

    // Overrides the genId method to ensure that a hero always has an id.
    // If the heroes array is empty,
    // the method below returns the initial number (11).
    // if the heroes array is not empty, the method below returns the highest
    // hero id + 1.
    genId(teams: Team[]): number {
      return teams.length > 0 ? Math.max(...teams.map(team => team.id)) + 1 : 3;
    }
  }
