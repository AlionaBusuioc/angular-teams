// import { Team } from './team';

// export const TEAMS: Team[] = [
//     {id: 11, Administrator: "Gheorghe", Description : "Front End"},
//     {id: 12, Administrator: "Gheorghe", Description : "Back End"}
//   ];